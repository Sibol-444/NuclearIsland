﻿#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stddef.h>

struct JsonCtx { const char* p; const char* end; };

static void jskip(JsonCtx* j) {
    while (j->p < j->end && (*j->p == ' ' || *j->p == '\t' || *j->p == '\r' || *j->p == '\n')) j->p++;
}

static void jskipValue(JsonCtx* j) {
    jskip(j);
    if (j->p >= j->end) return;
    char c = *j->p;
    if (c == '"') {
        j->p++;
        while (j->p < j->end && *j->p != '"') {
            if (*j->p == '\\') j->p++;
            if (j->p < j->end) j->p++;
        }
        if (j->p < j->end) j->p++;
    } else if (c == '{' || c == '[') {
        int depth = 1;
        j->p++;
        while (j->p < j->end && depth > 0) {
            char d = *j->p;
            if (d == '"') {
                j->p++;
                while (j->p < j->end && *j->p != '"') {
                    if (*j->p == '\\') j->p++;
                    if (j->p < j->end) j->p++;
                }
                if (j->p < j->end) j->p++;
            } else if (d == '{' || d == '[') {
                depth++;
                printf("  [+%c depth=%d]\n", d, depth);
                j->p++;
            } else if (d == '}' || d == ']') {
                depth--;
                if (depth == 0) { printf("  [depth0 on %c]\n", d); j->p++; }
                else { printf("  [-%c depth=%d]\n", d, depth); j->p++; }
            } else {
                j->p++;
            }
        }
        if (depth > 0) printf("  [skipValue UNFINISHED depth=%d char='%c']\n", depth, j->p < j->end ? *j->p : '?');
    } else {
        while (j->p < j->end && *j->p != ',' && *j->p != '}' && *j->p != ']') j->p++;
    }
}

static bool jFindString(JsonCtx* j, const char* key, char* out, size_t outSz);

static bool jSeekValue(JsonCtx* j, const char* key) {
    jskip(j);
    if (j->p >= j->end || *j->p != '{') return false;
    j->p++;
    size_t klen = strlen(key);
    while (j->p < j->end) {
        jskip(j);
        if (j->p >= j->end) return false;
        if (*j->p == '}') return false;
        if (*j->p == ',') { j->p++; continue; }
        if (*j->p != '"') { j->p++; continue; }
        j->p++;
        const char* ks = j->p;
        while (j->p < j->end && *j->p != '"') j->p++;
        if (j->p >= j->end) return false;
        size_t kl = (size_t)(j->p - ks);
        j->p++;
        jskip(j);
        if (j->p < j->end && *j->p == ':') j->p++; else continue;
        jskip(j);
        if (kl == klen && strncmp(ks, key, kl) == 0) return true;
        jskipValue(j);
    }
    return false;
}

static bool jFindString(JsonCtx* j, const char* key, char* out, size_t outSz) {
    jskip(j);
    if (j->p >= j->end || *j->p != '{') return false;
    j->p++;
    size_t klen = strlen(key);
    while (j->p < j->end) {
        jskip(j);
        if (j->p >= j->end) return false;
        if (*j->p == '}') return false;
        if (*j->p == ',') { j->p++; continue; }
        if (*j->p != '"') { j->p++; continue; }
        j->p++;
        const char* ks = j->p;
        while (j->p < j->end && *j->p != '"') j->p++;
        if (j->p >= j->end) return false;
        size_t kl = (size_t)(j->p - ks);
        j->p++;
        jskip(j);
        if (j->p < j->end && *j->p == ':') j->p++; else continue;
        jskip(j);
        if (kl == klen && strncmp(ks, key, kl) == 0 && j->p < j->end && *j->p == '"') {
            j->p++;
            size_t n = 0;
            while (j->p < j->end && *j->p != '"') {
                if (n + 1 < outSz) out[n++] = *j->p;
                j->p++;
            }
            out[n] = 0;
            return true;
        }
        jskipValue(j);
    }
    return false;
}

static int jFindInt(JsonCtx* j, const char* key) {
    jskip(j);
    if (j->p >= j->end || *j->p != '{') return -1;
    j->p++;
    size_t klen = strlen(key);
    while (j->p < j->end) {
        jskip(j);
        if (j->p >= j->end) return -1;
        if (*j->p == '}') return -1;
        if (*j->p == ',') { j->p++; continue; }
        if (*j->p != '"') { j->p++; continue; }
        j->p++;
        const char* ks = j->p;
        while (j->p < j->end && *j->p != '"') j->p++;
        if (j->p >= j->end) return -1;
        size_t kl = (size_t)(j->p - ks);
        j->p++; jskip(j);
        if (j->p < j->end && *j->p == ':') j->p++; else continue;
        jskip(j);
        if (kl == klen && strncmp(ks, key, kl) == 0 && j->p < j->end && (*j->p == '-' || (*j->p >= '0' && *j->p <= '9'))) {
            return atoi(j->p);
        }
        jskipValue(j);
    }
    return -1;
}

int main(int argc, char** argv) {
    if (argc < 2) { printf("usage: test_parse <jsonfile>\n"); return 1; }
    FILE* f = fopen(argv[1], "rb");
    if (!f) { printf("can't open\n"); return 1; }
    fseek(f, 0, SEEK_END);
    long sz = ftell(f);
    fseek(f, 0, SEEK_SET);
    char* buf = (char*)malloc(sz + 1);
    fread(buf, 1, sz, f);
    buf[sz] = 0;
    fclose(f);

    // emulate native: truncate to 64KB buffer
    size_t cap = 65536;
    if ((size_t)sz > cap) {
        buf[cap] = 0;
        for (long i = cap; i < sz; i++) buf[i] = 0; // safety (unused)
    }
    JsonCtx j{ buf, buf + cap };
    int idx = jFindInt(&j, "currentIndex");
    printf("currentIndex=%d\n", idx);

const char* p = buf;
    int trackNo = 0;
    const char* trackStart = NULL;
    while (p < buf + cap) {
        const char* t = strstr(p, "\"track\":{");
        if (!t) break;
        if (trackNo == idx) { trackStart = t; break; }
        trackNo++;
        p = t + 8;
    }
    if (!trackStart) { printf("track not found, trackNo=%d\n", trackNo); return 1; }
    printf("trackStart at %td\n", trackStart - buf);
    printf("trackStart ctx: [%.*s]\n", 50, trackStart - 20);
    const char* itemStart = trackStart + 8;
    if (*itemStart == '{') itemStart++; // move into object like jFindString
    JsonCtx tj{ itemStart, buf + sz };
    char title[256] = "";
    while (true) {
        jskip(&tj);
        if (tj.p >= tj.end) { printf("END\n"); break; }
        if (*tj.p == '}') { printf("see }\n"); break; }
        if (*tj.p == ',') { tj.p++; continue; }
        if (*tj.p != '"') { printf("see '%c' at %td ctx=[%.*s]\n", *tj.p, tj.p - buf, 25, tj.p); break; }
        tj.p++;
        const char* ks = tj.p;
        while (tj.p < tj.end && *tj.p != '"') tj.p++;
        ptrdiff_t kl = tj.p - ks;
        char k[64]; if (kl >= 63) kl = 63; memcpy(k, ks, kl); k[kl] = 0;
        printf("key=[%s]\n", k);
        tj.p++;
        jskip(&tj);
        bool isTitle = (strcmp(k, "title") == 0);
        if (tj.p < tj.end && *tj.p == ':') tj.p++;
        jskip(&tj);
        if (isTitle && tj.p < tj.end && *tj.p == '"') {
            tj.p++;
            size_t n = 0;
            while (tj.p < tj.end && *tj.p != '"' && n + 1 < sizeof(title)) title[n++] = *tj.p++;
            title[n] = 0;
            printf("FOUND title=[%s]\n", title);
            return 0;
        }
        jskipValue(&tj);
        printf("  after [%s] -> %td char='%c'\n", k, tj.p - buf, tj.p < tj.end ? *tj.p : '?');
    }
    printf("title ok=0 val=[]\n");
    return 0;
}

