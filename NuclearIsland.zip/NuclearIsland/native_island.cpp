#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <windowsx.h>
#include <winsock2.h>
#include <ws2tcpip.h>
#include <commctrl.h>
#include <shellapi.h>
#include <wchar.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#pragma comment(lib, "ws2_32.lib")
#pragma comment(lib, "gdi32.lib")
#pragma comment(lib, "user32.lib")
#pragma comment(lib, "kernel32.lib")
#pragma comment(lib, "advapi32.lib")

#define API_HOST "127.0.0.1"
#define API_PORT 4120
#define W 780
#define H 64
#define WM_TRAY (WM_APP + 1)
#define TRAY_ID 1

// ---------- tiny JSON helpers (no alloc) ----------
struct JsonCtx { const char* p; const char* end; };

static void jskip(JsonCtx* j) {
    while (j->p < j->end && (*j->p == ' ' || *j->p == '\t' || *j->p == '\r' || *j->p == '\n')) j->p++;
}

// skip a scalar/array/object value starting at j->p; leaves j->p after it
static void jskipValue(JsonCtx* j) {
    jskip(j);
    if (j->p >= j->end) return;
    char c = *j->p;
    if (c == '"') {
        j->p++;
        while (j->p < j->end && *j->p != '"') {
            if (*j->p == '\\') j->p++;
            if (j->p < j->end) j->p++;
        }
        if (j->p < j->end) j->p++; // closing quote
    } else if (c == '{' || c == '[') {
        int depth = 1;
        j->p++;
        while (j->p < j->end && depth > 0) {
            char d = *j->p;
            if (d == '"') {
                // skip string (may contain braces)
                j->p++;
                while (j->p < j->end && *j->p != '"') {
                    if (*j->p == '\\') j->p++;
                    if (j->p < j->end) j->p++;
                }
                if (j->p < j->end) j->p++;
            } else if (d == '{' || d == '[') {
                depth++;
                j->p++;
            } else if (d == '}' || d == ']') {
                depth--;
                j->p++;
            } else {
                j->p++;
            }
        }
    } else {
        while (j->p < j->end && *j->p != ',' && *j->p != '}' && *j->p != ']') j->p++;
    }
}

// reads UTF-8 string at j->p (which must be at '"') into out
static bool jTakeString(JsonCtx* j, char* out, size_t outSz) {
    jskip(j);
    if (j->p >= j->end || *j->p != '"') return false;
    j->p++;
    size_t n = 0;
    while (j->p < j->end && *j->p != '"') {
        char c = *j->p;
        if (c == '\\' && j->p + 1 < j->end) {
            char e = j->p[1];
            if (e == 'u' && j->p + 6 < j->end) {
                unsigned cp = 0;
                for (int k = 0; k < 4; k++) {
                    char h = j->p[2 + k];
                    cp <<= 4;
                    if (h >= '0' && h <= '9') cp += h - '0';
                    else if (h >= 'a' && h <= 'f') cp += h - 'a' + 10;
                    else if (h >= 'A' && h <= 'F') cp += h - 'A' + 10;
                }
                if (cp < 0x80) { if (n + 1 < outSz) out[n++] = (char)cp; }
                else if (cp < 0x800) { if (n + 2 < outSz) { out[n++] = (char)(0xC0 | (cp >> 6)); out[n++] = (char)(0x80 | (cp & 0x3F)); } }
                else { if (n + 3 < outSz) { out[n++] = (char)(0xE0 | (cp >> 12)); out[n++] = (char)(0x80 | ((cp >> 6) & 0x3F)); out[n++] = (char)(0x80 | (cp & 0x3F)); } }
                j->p += 6;
                continue;
            }
            char rep = e;
            if (e == 'n' || e == 'r' || e == 't') rep = ' ';
            if (n + 1 < outSz) out[n++] = rep;
            j->p += 2;
            continue;
        }
        if (n + 1 < outSz) out[n++] = c;
        j->p++;
    }
    out[n] = 0;
    if (j->p < j->end) j->p++; // closing quote
    return true;
}

// j must be at '{'. return true when key with exactly klen matches at this level.
static bool jKeyAtLevel(JsonCtx* j, const char* key, size_t klen) {
    jskip(j);
    if (j->p >= j->end || *j->p != '{') return false;
    j->p++;
    while (j->p < j->end) {
        jskip(j);
        if (j->p >= j->end) return false;
        if (*j->p == '}') return false;
        if (*j->p == ',') { j->p++; continue; }
        if (*j->p != '"') { j->p++; continue; }
        j->p++;
        const char* ks = j->p;
        while (j->p < j->end && *j->p != '"') j->p++;
        if (j->p >= j->end) return false;
        size_t kl = (size_t)(j->p - ks);
        j->p++;
        jskip(j);
        bool colon = (j->p < j->end && *j->p == ':');
        if (colon) j->p++;
        jskip(j);
        bool hasStr = (j->p < j->end && *j->p == '"');
        if (colon && kl == klen && strncmp(ks, key, kl) == 0) {
            if (hasStr) { jTakeString(j, (char*)ks, 0); } // mark consumed; caller re-reads
            return true;
        }
        jskipValue(j);
        jskip(j);
    }
    return false;
}

static bool jFindString(JsonCtx* j, const char* key, char* out, size_t outSz);

// j at '{': seek key and leave position at its value unless value is string (then it is taken).
static bool jSeekValue(JsonCtx* j, const char* key) {
    jskip(j);
    if (j->p >= j->end || *j->p != '{') return false;
    j->p++;
    size_t klen = strlen(key);
    while (j->p < j->end) {
        jskip(j);
        if (j->p >= j->end) return false;
        if (*j->p == '}') return false;
        if (*j->p == ',') { j->p++; continue; }
        if (*j->p != '"') { j->p++; continue; }
        j->p++;
        const char* ks = j->p;
        while (j->p < j->end && *j->p != '"') j->p++;
        if (j->p >= j->end) return false;
        size_t kl = (size_t)(j->p - ks);
        j->p++;
        jskip(j);
        if (j->p < j->end && *j->p == ':') j->p++; else continue;
        jskip(j);
        if (kl == klen && strncmp(ks, key, kl) == 0) return true;
        jskipValue(j);
    }
    return false;
}

// looks up name under the first element of an array of objects: "...":[{...}]
static void jFirstArtistName(const char* pos, const char* end, char* out, size_t outSz) {
    out[0] = 0;
    if (!pos || pos >= end) return;
    JsonCtx scope{ pos, end };
    if (!jSeekValue(&scope, "artists")) return;
    if (scope.p >= scope.end) return;
    if (*scope.p == '[') {
        scope.p++;
        jskip(&scope);
        if (scope.p < scope.end && *scope.p == '{') {
            JsonCtx el{ scope.p, end };
            jFindString(&el, "name", out, outSz);
        }
    }
}

// j must be at '{'. seek a member at the same level; if its value is a string, copy to out (UTF-8).
static bool jFindString(JsonCtx* j, const char* key, char* out, size_t outSz) {
    jskip(j);
    if (j->p >= j->end || *j->p != '{') return false;
    j->p++;
    size_t klen = strlen(key);
    while (j->p < j->end) {
        jskip(j);
        if (j->p >= j->end) return false;
        if (*j->p == '}') return false;
        if (*j->p == ',') { j->p++; continue; }
        if (*j->p != '"') { j->p++; continue; }
        j->p++;
        const char* ks = j->p;
        while (j->p < j->end && *j->p != '"') j->p++;
        if (j->p >= j->end) return false;
        size_t kl = (size_t)(j->p - ks);
        j->p++;
        jskip(j);
        if (j->p < j->end && *j->p == ':') j->p++; else continue;
        jskip(j);
        if (kl == klen && strncmp(ks, key, kl) == 0 && j->p < j->end && *j->p == '"') {
            jTakeString(j, out, outSz);
            return true;
        }
        jskipValue(j);
    }
    return false;
}

static int jFindInt(JsonCtx* j, const char* key) {
    jskip(j);
    if (j->p >= j->end || *j->p != '{') return -1;
    j->p++;
    size_t klen = strlen(key);
    while (j->p < j->end) {
        jskip(j);
        if (j->p >= j->end) return -1;
        if (*j->p == '}') return -1;
        if (*j->p == ',') { j->p++; continue; }
        if (*j->p != '"') { j->p++; continue; }
        j->p++;
        const char* ks = j->p;
        while (j->p < j->end && *j->p != '"') j->p++;
        if (j->p >= j->end) return -1;
        size_t kl = (size_t)(j->p - ks);
        j->p++; jskip(j);
        if (j->p < j->end && *j->p == ':') j->p++; else continue;
        jskip(j);
        if (kl == klen && strncmp(ks, key, kl) == 0 && j->p < j->end && (*j->p == '-' || (*j->p >= '0' && *j->p <= '9'))) {
            return atoi(j->p);
        }
        jskipValue(j);
    }
    return -1;
}

// ---------- network ----------
static const char* HttpBody(const char* resp) {
    const char* h = strstr(resp, "\r\n\r\n");
    return h ? h + 4 : resp;
}

static bool HttpRequest(const char* req, char* buf, size_t bufsz) {
    WSADATA wsa;
    if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0) return false;
    SOCKET s = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (s == INVALID_SOCKET) { WSACleanup(); return false; }
    struct sockaddr_in addr;
    memset(&addr, 0, sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_port = htons(API_PORT);
    inet_pton(AF_INET, API_HOST, &addr.sin_addr);
    if (connect(s, (struct sockaddr*)&addr, sizeof(addr)) != 0) {
        closesocket(s); WSACleanup(); return false;
    }
    send(s, req, (int)strlen(req), 0);
    size_t used = 0;
    char tmp[4096];
    int n;
    // timeout so we don't hang
    DWORD to = 2500;
    setsockopt(s, SOL_SOCKET, SO_RCVTIMEO, (const char*)&to, sizeof(to));
    while ((n = recv(s, tmp, sizeof(tmp), 0)) > 0 && used < bufsz - 1) {
        size_t c = (size_t)n;
        if (used + c > bufsz - 1) c = bufsz - 1 - used;
        memcpy(buf + used, tmp, c);
        used += c;
    }
    buf[used] = 0;
    closesocket(s);
    WSACleanup();
    return used > 0;
}

// ---------- state ----------
static char g_title[256] = "";
static char g_artist[256] = "";
static char g_status[32] = "none";
static bool g_visible = true;
static bool g_exit = false;

static HWND s_hwnd = 0;
static HDC s_mdc = 0;
static HBITMAP s_bmp = 0, s_old = 0;
static HFONT fTitle = 0, fArtist = 0, fGlyph = 0;

static void FetchNowPlaying();

static void FetchPost(const char* cmd) {
    char req[256];
    snprintf(req, sizeof(req),
        "POST /api/playback/%s HTTP/1.1\r\nHost: 127.0.0.1:4120\r\nContent-Length: 0\r\nConnection: close\r\n\r\n", cmd);
    char resp[4096];
    HttpRequest(req, resp, sizeof(resp));
    FetchNowPlaying();
    if (s_hwnd) {
        RECT r; GetClientRect(s_hwnd, &r);
        InvalidateRect(s_hwnd, &r, FALSE);
    }
}

static void FetchNowPlaying() {
    static unsigned long long lastLog = 0;
    unsigned long long now = (unsigned long long)GetTickCount64();
    bool logThis = now - lastLog > 30000;
    if (logThis) lastLog = now;

    static char resq[716800];
    static char resb[16384];
    char cur[16] = "none";
    if (HttpRequest("GET /api/playback HTTP/1.1\r\nHost: 127.0.0.1:4120\r\nConnection: close\r\n\r\n", resb, sizeof(resb))) {
        const char* b = HttpBody(resb);
        JsonCtx j{ b, b + strlen(b) };
        char st[16] = "";
        if (jFindString(&j, "status", st, sizeof(st))) {
            if (st[0]) strncpy(cur, st, 15);
        }
    }
    strncpy(g_status, cur, sizeof(g_status) - 1);

    if (HttpRequest("GET /api/queue HTTP/1.1\r\nHost: 127.0.0.1:4120\r\nConnection: close\r\n\r\n", resq, sizeof(resq))) {
        const char* b = HttpBody(resq);
        JsonCtx j{ b, b + strlen(b) };
        int idx = jFindInt(&j, "currentIndex");
        if (idx >= 0) {
            // scan "track":{"...":"title"...}: idx-th occurrence
            char title[256] = ""; char artist[256] = "";
            const char* p = b;
            const char* end = b + strlen(b);
            int trackNo = 0;
            while (p < end) {
                const char* t = strstr(p, "\"track\":{");
                if (!t) break;
                if (trackNo == idx) {
                    const char* itemStart = t + 8; // after "{"
                    JsonCtx tj{ itemStart, end };
                    jFindString(&tj, "title", title, sizeof(title));
                    jFirstArtistName(itemStart, end, artist, sizeof(artist));
                    break;
                }
                trackNo++;
                p = t + 8;
            }
            if (title[0]) strncpy(g_title, title, sizeof(g_title) - 1);
            if (artist[0]) strncpy(g_artist, artist, sizeof(g_artist) - 1);
        }
    }

    if (logThis) {
        char line[2048];
        int n = snprintf(line, sizeof(line), "[%llu] title=[%s] artist=[%s] status=[%s]\r\n",
            now, g_title, g_artist, g_status);
        HANDLE f = CreateFileW(L"C:\\Users\\solov\\Documents\\Default Project\\NuclearIsland\\native_island.log",
            GENERIC_WRITE, FILE_SHARE_READ, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
        if (f != INVALID_HANDLE_VALUE) {
            SetFilePointer(f, 0, NULL, FILE_END);
            DWORD w;
            WriteFile(f, line, (DWORD)n, &w, NULL);
            CloseHandle(f);
        }
    }
}

// ---------- drawing ----------
static void EnsureFonts(HDC dc) {
    if (!fTitle) {
        fTitle = CreateFontW(-19, 0, 0, 0, FW_SEMIBOLD, 0, 0, 0, DEFAULT_CHARSET,
            OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY, DEFAULT_PITCH | FF_SWISS, L"Segoe UI");
        fArtist = CreateFontW(-17, 0, 0, 0, FW_NORMAL, 0, 0, 0, DEFAULT_CHARSET,
            OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY, DEFAULT_PITCH | FF_SWISS, L"Segoe UI");
        fGlyph = CreateFontW(-24, 0, 0, 0, FW_NORMAL, 0, 0, 0, DEFAULT_CHARSET,
            OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, ANTIALIASED_QUALITY, DEFAULT_PITCH | FF_SWISS, L"Segoe UI Symbol");
    }
}

static void SetPixel24(void* px, int w, int x, int y, unsigned r, unsigned g, unsigned b) {
    if (x < 0 || y < 0 || x >= w) return;
    unsigned* p = (unsigned*)px;
    p[y * w + x] = (r << 16) | (g << 8) | b;
}

static void DrawIsland(HDC dc, int w, int h) {
    EnsureFonts(dc);
    HBRUSH bg = CreateSolidBrush(RGB(24, 24, 27));
    HGDIOBJ ob = SelectObject(dc, bg);
    RoundRect(dc, 0, 0, w, h, 20, 20);
    SelectObject(dc, ob);
    DeleteObject(bg);

    HGDIOBJ opn = SelectObject(dc, CreatePen(PS_SOLID, 1, RGB(60, 60, 68)));
    HGDIOBJ obr = SelectObject(dc, GetStockObject(NULL_BRUSH));
    RoundRect(dc, 0, 0, w - 1, h - 1, 20, 20);
    SelectObject(dc, opn);
    SelectObject(dc, obr);

    SetBkMode(dc, TRANSPARENT);

    // buttons right
    int bx = w - 3 * 44 - 12;
    int by = 15;
    const int bs = 34;
    for (int i = 0; i < 3; i++) {
        int cx = bx + i * 44 + bs / 2;
        HBRUSH hb = CreateSolidBrush(RGB(38, 38, 42));
        HGDIOBJ ob2 = SelectObject(dc, hb);
        HGDIOBJ opn2 = SelectObject(dc, CreatePen(PS_SOLID, 1, RGB(55, 55, 62)));
        HGDIOBJ obr2 = SelectObject(dc, GetStockObject(NULL_BRUSH));
        Ellipse(dc, cx - bs / 2, by, cx + bs / 2, by + bs);
        SelectObject(dc, obr2);
        SelectObject(dc, opn2);
        SelectObject(dc, ob2);
        DeleteObject(hb);
    }

    SelectObject(dc, fGlyph);
    SetTextColor(dc, RGB(215, 215, 220));
    for (int i = 0; i < 3; i++) {
        int cx = bx + i * 44 + bs / 2;
        RECT rt{ cx - 40, by, cx + 40, by + bs };
        const wchar_t* gl = L"\u23EE";
        if (i == 1) {
            if (g_status[0] && g_status[0] == 'p' && strcmp(g_status, "paused") == 0) gl = L"\u25B6";
            else gl = L"\u23F8";
            if (strcmp(g_status, "none") == 0 || !g_status[0]) gl = L"\u25B6";
        }
        if (i == 2) gl = L"\u23ED";
        DrawTextW(dc, gl, -1, &rt, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_NOCLIP);
    }

    // text
    int tx = 26;
    int maxW = bx - 20;
    wchar_t wt[512], wa[512];
    MultiByteToWideChar(CP_UTF8, 0, g_title, -1, wt, 512);
    MultiByteToWideChar(CP_UTF8, 0, g_artist, -1, wa, 512);
    if (!g_title[0]) {
        if (strcmp(g_status, "none") == 0) wcscpy_s(wt, 512, L"Nuclear не запущен");
        else if (strcmp(g_status, "paused") == 0) { wcscpy_s(wt, 512, L"Пауза"); wa[0] = 0; }
        else { wcscpy_s(wt, 512, L"Загрузка..."); wa[0] = 0; }
    }
    RECT tt{ tx, 7, tx + maxW, 30 };
    RECT ta{ tx, 31, tx + maxW, 53 };
    SetTextColor(dc, RGB(235, 235, 240));
    SelectObject(dc, fTitle);
    DrawTextW(dc, wt, -1, &tt, DT_SINGLELINE | DT_VCENTER | DT_END_ELLIPSIS | DT_NOCLIP);
    SetTextColor(dc, RGB(175, 175, 185));
    SelectObject(dc, fArtist);
    DrawTextW(dc, wa, -1, &ta, DT_SINGLELINE | DT_VCENTER | DT_END_ELLIPSIS | DT_NOCLIP);
}

static void Repaint(HWND hwnd) {
    PAINTSTRUCT ps;
    HDC dc = BeginPaint(hwnd, &ps);
    RECT rc; GetClientRect(hwnd, &rc);
    FillRect(dc, &rc, (HBRUSH)GetStockObject(HOLLOW_BRUSH));
    DrawIsland(dc, rc.right, rc.bottom);
    EndPaint(hwnd, &ps);
}

static int ButtonAt(int x) {
    int bx = W - 3 * 44 - 12;
    int bs = 34;
    for (int i = 0; i < 3; i++)
        if (abs(x - (bx + i * 44 + bs / 2)) <= 17) return i;
    return -1;
}

static void ToggleVisible(HWND hwnd) {
    g_visible = !g_visible;
    if (g_visible) {
        ShowWindow(hwnd, SW_SHOW);
        SetWindowPos(hwnd, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);
    } else {
        RECT r; GetWindowRect(hwnd, &r);
        ShowWindow(hwnd, SW_HIDE);
        // force desktop to repaint the area the island occupied
        RedrawWindow(GetDesktopWindow(), &r, NULL, RDW_INVALIDATE | RDW_ALLCHILDREN | RDW_UPDATENOW);
    }
}

static bool IsAutorun() {
    HKEY k;
    if (RegOpenKeyExW(HKEY_CURRENT_USER, L"Software\\Microsoft\\Windows\\CurrentVersion\\Run",
        0, KEY_READ, &k) != ERROR_SUCCESS) return false;
    wchar_t buf[MAX_PATH]; DWORD sz = sizeof(buf), t;
    bool ok = RegQueryValueExW(k, L"NuclearIsland", NULL, &t, (LPBYTE)buf, &sz) == ERROR_SUCCESS;
    RegCloseKey(k);
    return ok;
}

static void ToggleAutorun() {
    HKEY k;
    if (RegOpenKeyExW(HKEY_CURRENT_USER, L"Software\\Microsoft\\Windows\\CurrentVersion\\Run",
        0, KEY_SET_VALUE, &k) != ERROR_SUCCESS) return;
    if (IsAutorun()) {
        RegDeleteValueW(k, L"NuclearIsland");
    } else {
        wchar_t path[MAX_PATH];
        GetModuleFileNameW(NULL, path, MAX_PATH);
        wchar_t val[MAX_PATH + 16];
        swprintf(val, MAX_PATH + 16, L"\"%s\"", path);
        RegSetValueExW(k, L"NuclearIsland", 0, REG_SZ, (const BYTE*)val,
            (DWORD)((wcslen(val) + 1) * sizeof(wchar_t)));
    }
    RegCloseKey(k);
}

static bool AddTrayIcon(HWND hwnd) {
    NOTIFYICONDATAW nid{};
    nid.cbSize = sizeof(nid);
    nid.hWnd = hwnd;
    nid.uID = TRAY_ID;
    nid.uFlags = NIF_MESSAGE | NIF_ICON | NIF_TIP;
    nid.uCallbackMessage = WM_TRAY;
    nid.hIcon = LoadIconW(NULL, (LPCWSTR)IDI_APPLICATION);
    lstrcpynW(nid.szTip, L"Nuclear Island", ARRAYSIZE(nid.szTip));
    return Shell_NotifyIconW(NIM_ADD, &nid) != FALSE;
}

static void DeleteTrayIcon(HWND hwnd) {
    NOTIFYICONDATAW nid{};
    nid.cbSize = sizeof(nid);
    nid.hWnd = hwnd;
    nid.uID = TRAY_ID;
    Shell_NotifyIconW(NIM_DELETE, &nid);
}

static void ShowTrayMenu(HWND hwnd) {
    POINT pt; GetCursorPos(&pt);
    HMENU m = CreatePopupMenu();
    AppendMenuW(m, MF_STRING, 1, L"Показать/скрыть");
    AppendMenuW(m, MF_STRING | (IsAutorun() ? MF_CHECKED : 0), 3, L"Автозагрузка");
    AppendMenuW(m, MF_SEPARATOR, 0, NULL);
    AppendMenuW(m, MF_STRING, 2, L"Выход");
    SetMenuDefaultItem(m, 1, FALSE);
    int cmd = TrackPopupMenu(m, TPM_RETURNCMD | TPM_RIGHTBUTTON | TPM_NONOTIFY, pt.x, pt.y, 0, hwnd, NULL);
    DestroyMenu(m);
    if (cmd == 1) ToggleVisible(hwnd);
    if (cmd == 2) { g_exit = true; PostMessage(hwnd, WM_CLOSE, 0, 0); }
    if (cmd == 3) ToggleAutorun();
}

// ---------- window ----------
static void LogLine(const char* fmt, ...) {
    char line[1024];
    va_list ap; va_start(ap, fmt);
    int n = vsnprintf(line, sizeof(line), fmt, ap);
    va_end(ap);
    if (n < 0) return;
    unsigned long long now = (unsigned long long)GetTickCount64();
    char full[1100];
    int m = snprintf(full, sizeof(full), "[%llu] %s\r\n", now, line);
    HANDLE f = CreateFileW(L"C:\\Users\\solov\\Documents\\Default Project\\NuclearIsland\\native_island.log",
        GENERIC_WRITE, FILE_SHARE_READ, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
    if (f != INVALID_HANDLE_VALUE) {
        SetFilePointer(f, 0, NULL, FILE_END);
        DWORD w;
        WriteFile(f, full, (DWORD)m, &w, NULL);
        CloseHandle(f);
    }
}

static LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp) {
    switch (msg) {
    case WM_CREATE: {
        s_hwnd = hwnd;
        SetTimer(hwnd, 1, 1500, NULL);
        HRGN rgn = CreateRoundRectRgn(0, 0, W + 1, H + 1, 40, 40);
        SetWindowRgn(hwnd, rgn, FALSE);
        SetLayeredWindowAttributes(hwnd, 0, 245, LWA_ALPHA);
        AddTrayIcon(hwnd);
        FetchNowPlaying();
        return 0;
    }
    case WM_TRAY:
        if (lp == WM_LBUTTONDBLCLK || lp == WM_LBUTTONUP) ToggleVisible(hwnd);
        else if (lp == WM_RBUTTONUP || lp == WM_CONTEXTMENU) ShowTrayMenu(hwnd);
        return 0;
    case WM_TIMER:
        if (wp == 1) {
            FetchNowPlaying();
            InvalidateRect(hwnd, NULL, FALSE);
        }
        return 0;
    case WM_LBUTTONDOWN: {
        int x = GET_X_LPARAM(lp);
        int i = ButtonAt(x);
        if (i == 0) FetchPost("previous");
        else if (i == 1) FetchPost("toggle");
        else if (i == 2) FetchPost("next");
        return 0;
    }
    case WM_RBUTTONUP: {
        POINT pt; GetCursorPos(&pt);
        HMENU m = CreatePopupMenu();
        AppendMenuW(m, MF_STRING, 1, L"Показать/скрыть");
        AppendMenuW(m, MF_STRING | (IsAutorun() ? MF_CHECKED : 0), 3, L"Автозагрузка");
        AppendMenuW(m, MF_SEPARATOR, 0, NULL);
        AppendMenuW(m, MF_STRING, 2, L"Выход");
        int cmd = TrackPopupMenu(m, TPM_RETURNCMD | TPM_RIGHTBUTTON | TPM_NONOTIFY, pt.x, pt.y, 0, hwnd, NULL);
        DestroyMenu(m);
        if (cmd == 1) ToggleVisible(hwnd);
        if (cmd == 2) { g_exit = true; PostMessage(hwnd, WM_CLOSE, 0, 0); }
        if (cmd == 3) ToggleAutorun();
        return 0;
    }
    case WM_HOTKEY:
        if (wp == 10) ToggleVisible(hwnd);
        else if (wp == 11) FetchPost("previous");
        else if (wp == 12) FetchPost("next");
        else if (wp == 13) FetchPost("toggle");
        return 0;
    case WM_SYSCOMMAND:
        if ((wp & 0xFFF0) == SC_CLOSE) {
            LogLine("WM_SYSCOMMAND SC_CLOSE");
            g_visible = false; ShowWindow(hwnd, SW_HIDE);
            return 0;
        }
        break;
    case WM_CLOSE:
        LogLine("WM_CLOSE g_exit=%d", g_exit ? 1 : 0);
        if (g_exit) { DestroyWindow(hwnd); return 0; }
        g_visible = false; ShowWindow(hwnd, SW_HIDE);
        return 0;
    case WM_QUERYENDSESSION:
        return TRUE;
    case WM_ENDSESSION:
        LogLine("WM_ENDSESSION wParam=%d", (int)wp);
        g_exit = true; DestroyWindow(hwnd);
        return 0;
    case WM_DESTROY:
        LogLine("WM_DESTROY");
        KillTimer(hwnd, 1);
        DeleteTrayIcon(hwnd);
        PostQuitMessage(0);
        return 0;
    case WM_PAINT:
        Repaint(hwnd);
        return 0;
    case WM_ERASEBKGND:
        return 1;
    }
    return DefWindowProcW(hwnd, msg, wp, lp);
}

int WINAPI wWinMain(HINSTANCE hInst, HINSTANCE, LPWSTR, int) {
    WNDCLASSEXW wc{};
    wc.cbSize = sizeof(wc);
    wc.lpfnWndProc = WndProc;
    wc.hInstance = hInst;
    wc.hCursor = LoadCursor(NULL, IDC_ARROW);
    wc.hbrBackground = (HBRUSH)GetStockObject(BLACK_BRUSH);
    wc.lpszClassName = L"NuclearIslandNative";
    RegisterClassExW(&wc);

    HWND hwnd = CreateWindowExW(
        WS_EX_TOPMOST | WS_EX_TOOLWINDOW | WS_EX_LAYERED | WS_EX_NOACTIVATE,
        L"NuclearIslandNative", L"", WS_POPUP,
        0, 0, W, H, NULL, NULL, hInst, NULL);

    RegisterHotKey(hwnd, 10, MOD_CONTROL | MOD_SHIFT, 'F');
    RegisterHotKey(hwnd, 11, MOD_CONTROL | MOD_SHIFT, VK_LEFT);
    RegisterHotKey(hwnd, 12, MOD_CONTROL | MOD_SHIFT, VK_RIGHT);
    RegisterHotKey(hwnd, 13, MOD_CONTROL | MOD_SHIFT, VK_SPACE);

    RECT wa;
    SystemParametersInfoW(SPI_GETWORKAREA, 0, &wa, 0);
    int x = wa.left + (wa.right - wa.left - W) / 2;
    SetWindowPos(hwnd, HWND_TOPMOST, x, wa.top + 8, W, H, SWP_SHOWWINDOW | SWP_NOACTIVATE);

    MSG m;
    while (GetMessageW(&m, NULL, 0, 0) > 0) {
        TranslateMessage(&m);
        DispatchMessageW(&m);
    }
    return 0;
}