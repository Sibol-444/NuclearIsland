@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "C:\Windows\TEMP\opencode\smtcprobe.ps1" > "C:\Users\solov\Documents\Default Project\NuclearIsland\smtcconsole.log" 2>&1