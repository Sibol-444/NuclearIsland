@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "C:\Users\solov\Documents\Default Project\NuclearIsland\smtcprobe2.ps1" > C:\Users\solov\Documents\Default Project\NuclearIsland\c2.log 2>&1
