﻿$ErrorActionPreference='Continue'
$log='C:\Users\solov\Documents\Default Project\NuclearIsland\smtcprobe.log'
function Task-GetResult([object]$op,[type]$resultType){
  $gac='C:\Windows\Microsoft.NET\assembly\GAC_MSIL\System.Runtime.WindowsRuntime\v4.0_4.0.0.0__b77a5c561934e089\System.Runtime.WindowsRuntime.dll'
  $null=[Reflection.Assembly]::LoadFrom($gac)
  $extT=[System.WindowsRuntimeSystemExtensions]
  $m=$extT.GetMethods()|Where-Object{$_.Name -eq 'AsTask' -and $_.IsGenericMethod -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1'}|Select-Object -First 1
  $gm=$m.MakeGenericMethod($resultType)
  return $gm.Invoke($null,@($op)).GetAwaiter().GetResult()
}
try{
  [void][Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager, Windows, ContentType=WindowsRuntime]
  $mgr=Task-GetResult ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager]::RequestAsync()) ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager])
  $ss=$mgr.GetSessions()
  Add-Content $log ('SESSIONS='+$ss.Size) -Encoding UTF8
  foreach($s in $ss){ try{ $info=Task-GetResult ($s.TryGetMediaPropertiesAsync()) ([Windows.Media.Control.MediaProperties.MediaPropertiesInfo]); $pi=$s.GetPlaybackInfo(); Add-Content $log ('APP='+$s.SourceAppUserModelId+' | '+$pi.PlaybackStatus+' | '+$info.Title) -Encoding UTF8 }catch{ Add-Content $log ('ERR '+$_.Exception.Message) -Encoding UTF8 } }
}catch{
  $e=$_.Exception
  while($e -ne $null){ Add-Content $log ('EX ' + $e.GetType().FullName + ' :: ' + $e.Message) -Encoding UTF8 ; $e=$e.InnerException }
}
Add-Content $log ('DONE '+ (Get-Date)) -Encoding UTF8
