$ErrorActionPreference = 'Continue'
$log = 'C:\Users\solov\Documents\Default Project\NuclearIsland\smtcprobe.log'
'SMTC PROBE START ' + (Get-Date) | Out-File $log -Encoding utf8
$gac = 'C:\Windows\Microsoft.NET\assembly\GAC_MSIL\System.Runtime.WindowsRuntime\v4.0_4.0.0.0__b77a5c561934e089\System.Runtime.WindowsRuntime.dll'
$null = [Reflection.Assembly]::LoadFrom($gac)
$extT = [System.WindowsRuntimeSystemExtensions]
function Task-GetResult([object]$op, [type]$resultType) {
  $m = $extT.GetMethods() | Where-Object { $_.Name -eq 'AsTask' -and $_.IsGenericMethod -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1' } | Select-Object -First 1
  $gm = $m.MakeGenericMethod($resultType)
  return $gm.Invoke($null, @($op)).GetAwaiter().GetResult()
}
try {
  [void][Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager, Windows, ContentType = WindowsRuntime]
  $mgr = Task-GetResult ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager]::RequestAsync()) ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager])
  $sessions = $mgr.GetSessions()
  ('SESSIONS: ' + $sessions.Size) | Out-File $log -Append -Encoding utf8
  foreach ($s in $sessions) {
    try {
      $info = Task-GetResult ($s.TryGetMediaPropertiesAsync()) ([Windows.Media.Control.MediaProperties.MediaPropertiesInfo])
      $pi = $s.GetPlaybackInfo()
      if ($pi) { $st = $pi.PlaybackStatus } else { $st = '?' }
      ('APP=' + $s.SourceAppUserModelId + ' | ' + $st + ' | ' + $info.Title + ' | ' + $info.Artist) | Out-File $log -Append -Encoding utf8
    } catch {
      ('ERR session: ' + $_.Exception.Message) | Out-File $log -Append -Encoding utf8
    }
  }
} catch {
  ('FAIL: ' + $_.Exception.ToString()) | Out-File $log -Append -Encoding utf8
}
('SMTC PROBE DONE ' + (Get-Date)) | Out-File $log -Append -Encoding utf8