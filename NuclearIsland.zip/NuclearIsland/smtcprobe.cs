using System;
using System.Threading.Tasks;

class SmtcProbe
{
    [System.Runtime.InteropServices.DllImport("kernel32.dll")]
    static extern int RoInitialize(int type);

    static void Main()
    {
        RoInitialize(0);
        try
        {
            var mgr = Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager.RequestAsync().GetAwaiter().GetResult();
            var sessions = mgr.GetSessions();
            Console.WriteLine("SESSIONS: " + sessions.Size);
            foreach (var s in sessions)
            {
                try
                {
                    var info = s.TryGetMediaPropertiesAsync().GetAwaiter().GetResult();
                    var pi = s.GetPlaybackInfo();
                    Console.WriteLine("APP=" + s.SourceAppUserModelId + " | " + pi.PlaybackStatus + " | " + info.Title + " | " + info.Artist);
                }
                catch (Exception e)
                {
                    Console.WriteLine("ERR session: " + e.Message);
                }
            }
        }
        catch (Exception e)
        {
            Console.WriteLine("FAIL: " + e.Message);
        }
    }
}