﻿#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stddef.h>

struct JsonCtx { const char* p; const char* end; };
static const char* g_buf = 0;

static void jskip(JsonCtx* j) {
    while (j->p < j->end && (*j->p == ' ' || *j->p == '\t' || *j->p == '\r' || *j->p == '\n')) j->p++;
}

static void jskipValue(JsonCtx* j) {
    jskip(j);
    if (j->p >= j->end) return;
    char c = *j->p;
    if (c == '"') {
        j->p++;
        while (j->p < j->end && *j->p != '"') {
            if (*j->p == '\\') j->p++;
            if (j->p < j->end) j->p++;
        }
        if (j->p < j->end) j->p++;
    } else if (c == '{' || c == '[') {
        int depth = 1;
        j->p++;
        while (j->p < j->end && depth > 0) {
            char d = *j->p;
            if (d == '"') {
                j->p++;
                while (j->p < j->end && *j->p != '"') {
                    if (*j->p == '\\') j->p++;
                    if (j->p < j->end) j->p++;
                }
                if (j->p < j->end) j->p++;
            } else if (d == '{' || d == '[') {
                depth++;
                j->p++;
            } else if (d == '}' || d == ']') {
                depth--;
                j->p++;
            } else {
                j->p++;
            }
        }
    } else {
        while (j->p < j->end && *j->p != ',' && *j->p != '}' && *j->p != ']') j->p++;
    }
}

static bool jTakeString(JsonCtx* j, char* out, size_t outSz) {
    jskip(j);
    if (j->p >= j->end || *j->p != '"') return false;
    j->p++;
    size_t n = 0;
    while (j->p < j->end && *j->p != '"') {
        char c = *j->p;
        if (c == '\\' && j->p + 1 < j->end) {
            char e = j->p[1];
            if (e == 'u' && j->p + 6 < j->end) {
                unsigned cp = 0;
                for (int k = 0; k < 4; k++) {
                    char h = j->p[2 + k];
                    cp <<= 4;
                    if (h >= '0' && h <= '9') cp += h - '0';
                    else if (h >= 'a' && h <= 'f') cp += h - 'a' + 10;
                    else if (h >= 'A' && h <= 'F') cp += h - 'A' + 10;
                }
                if (cp < 0x80) { if (n + 1 < outSz) out[n++] = (char)cp; }
                else if (cp < 0x800) { if (n + 2 < outSz) { out[n++] = (char)(0xC0 | (cp >> 6)); out[n++] = (char)(0x80 | (cp & 0x3F)); } }
                else { if (n + 3 < outSz) { out[n++] = (char)(0xE0 | (cp >> 12)); out[n++] = (char)(0x80 | ((cp >> 6) & 0x3F)); out[n++] = (char)(0x80 | (cp & 0x3F)); } }
                j->p += 6;
                continue;
            }
            char rep = e;
            if (e == 'n' || e == 'r' || e == 't') rep = ' ';
            if (n + 1 < outSz) out[n++] = rep;
            j->p += 2;
            continue;
        }
        if (n + 1 < outSz) out[n++] = c;
        j->p++;
    }
    out[n] = 0;
    if (j->p < j->end) j->p++;
    return true;
}

static bool jFindString(JsonCtx* j, const char* key, char* out, size_t outSz);

static bool jSeekValue(JsonCtx* j, const char* key) {
    jskip(j);
    if (j->p >= j->end || *j->p != '{') return false;
    j->p++;
    size_t klen = strlen(key);
    while (j->p < j->end) {
        jskip(j);
        if (j->p >= j->end) return false;
        if (*j->p == '}') return false;
        if (*j->p == ',') { j->p++; continue; }
        if (*j->p != '"') { j->p++; continue; }
        j->p++;
        const char* ks = j->p;
        while (j->p < j->end && *j->p != '"') j->p++;
        if (j->p >= j->end) return false;
        size_t kl = (size_t)(j->p - ks);
        j->p++;
        jskip(j);
        if (j->p < j->end && *j->p == ':') j->p++; else continue;
        jskip(j);
        if (kl == klen && strncmp(ks, key, kl) == 0) return true;
        jskipValue(j);
    }
    return false;
}

static bool jFindString(JsonCtx* j, const char* key, char* out, size_t outSz) {
    jskip(j);
    if (j->p >= j->end || *j->p != '{') return false;
    j->p++;
    size_t klen = strlen(key);
    while (j->p < j->end) {
        jskip(j);
        if (j->p >= j->end) return false;
        if (*j->p == '}') return false;
        if (*j->p == ',') { j->p++; continue; }
        if (*j->p != '"') { j->p++; continue; }
        j->p++;
        const char* ks = j->p;
        while (j->p < j->end && *j->p != '"') j->p++;
        if (j->p >= j->end) return false;
        size_t kl = (size_t)(j->p - ks);
        j->p++;
        jskip(j);
        if (j->p < j->end && *j->p == ':') j->p++; else continue;
        jskip(j);
        if (kl == klen && strncmp(ks, key, kl) == 0 && j->p < j->end && *j->p == '"') {
            jTakeString(j, out, outSz);
            return true;
        }
        jskipValue(j);
    }
    return false;
}

static int jFindInt(JsonCtx* j, const char* key) {
    jskip(j);
    if (j->p >= j->end || *j->p != '{') return -1;
    j->p++;
    size_t klen = strlen(key);
    while (j->p < j->end) {
        jskip(j);
        if (j->p >= j->end) return -1;
        if (*j->p == '}') return -1;
        if (*j->p == ',') { j->p++; continue; }
        if (*j->p != '"') { j->p++; continue; }
        j->p++;
        const char* ks = j->p;
        while (j->p < j->end && *j->p != '"') j->p++;
        if (j->p >= j->end) return -1;
        size_t kl = (size_t)(j->p - ks);
        j->p++; jskip(j);
        if (j->p < j->end && *j->p == ':') j->p++; else continue;
        jskip(j);
        if (kl == klen && strncmp(ks, key, kl) == 0 && j->p < j->end && (*j->p == '-' || (*j->p >= '0' && *j->p <= '9'))) {
            return atoi(j->p);
        }
        jskipValue(j);
    }
    return -1;
}

static void jFirstArtistName(const char* pos, const char* end, char* out, size_t outSz) {
    out[0] = 0;
    if (!pos || pos >= end) return;
    JsonCtx scope{ pos, end };
    if (!jSeekValue(&scope, "artists")) return;
    if (scope.p >= scope.end) return;
    if (*scope.p == '[') {
        scope.p++;
        jskip(&scope);
        if (scope.p < scope.end && *scope.p == '{') {
            JsonCtx el{ scope.p, end };
            jFindString(&el, "name", out, outSz);
        }
    }
}

int main(int argc, char** argv) {
    if (argc < 2) { printf("usage: test_parse2 <jsonfile>\n"); return 1; }
    FILE* f = fopen(argv[1], "rb");
    if (!f) { printf("can't open\n"); return 1; }
    fseek(f, 0, SEEK_END);
    long sz = ftell(f);
    fseek(f, 0, SEEK_SET);
    char* buf = (char*)malloc(sz + 1);
    fread(buf, 1, sz, f);
    buf[sz] = 0;
    fclose(f);

    g_buf = buf;
    size_t cap = 65536;
    if ((size_t)sz > cap) buf[cap] = 0;

    JsonCtx j{ buf, buf + cap };
    int idx = jFindInt(&j, "currentIndex");
    printf("currentIndex=%d\n", idx);

    const char* p = buf;
    int trackNo = 0;
    const char* trackStart = NULL;
    while (p < buf + cap) {
        const char* t = strstr(p, "\"track\":{");
        if (!t) break;
        if (trackNo == idx) { trackStart = t; break; }
        trackNo++;
        p = t + 8;
    }
    if (!trackStart) { printf("track not found\n"); return 1; }

    const char* itemStart = trackStart + 8;
    JsonCtx tj{ itemStart, buf + cap };
    char title[256] = "";
    bool ok = jFindString(&tj, "title", title, sizeof(title));
    printf("title ok=%d val=[%s]\n", ok ? 1 : 0, title);

    char artist[256] = "";
    jFirstArtistName(itemStart, buf + cap, artist, sizeof(artist));
    printf("artist=[%s]\n", artist);
    return 0;
}



