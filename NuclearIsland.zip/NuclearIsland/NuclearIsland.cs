﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Globalization;
using System.IO;
using System.Net;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using System.Web.Script.Serialization;

namespace NuclearIsland
{
    public class AppContext : ApplicationContext
    {
        private IslandForm form;
        private NotifyIcon tray;
        private const string ApiBase = "http://127.0.0.1:4120";
        private const string McpBase = "http://127.0.0.1:8800/mcp";
        private List<PlaylistInfo> playlists = new List<PlaylistInfo>();
        private int currentPlaylistIndex = -1;
        private bool overlayVisible = true;
        private System.Windows.Forms.Timer pollTimer;

        public AppContext()
        {
            DebugLog("AppContext ctor start");
            form = new IslandForm(this);
            this.MainForm = form;

            tray = new NotifyIcon();
            tray.Icon = SystemIcons.Application;
            tray.Text = "NuclearIsland";
            tray.Visible = true;
            tray.ContextMenuStrip = new ContextMenuStrip();
            tray.ContextMenuStrip.Items.Add("Показать/скрыть (Ctrl+Shift+F)", null, (s, e) => ToggleOverlay());
            tray.ContextMenuStrip.Items.Add("Prev (Ctrl+Shift+Left)", null, (s, e) => SendCmd("previous"));
            tray.ContextMenuStrip.Items.Add("Next (Ctrl+Shift+Right)", null, (s, e) => SendCmd("next"));
            tray.ContextMenuStrip.Items.Add("Play/Pause (Ctrl+Shift+Space)", null, (s, e) => SendCmd("toggle"));
            tray.ContextMenuStrip.Items.Add("Следующий плейлист (Ctrl+Shift+])", null, (s, e) => { var _ = SwitchPlaylist(1); });
            tray.ContextMenuStrip.Items.Add("Выход", null, (s, e) => Exit());

            HotkeyManager.Register(form.Handle, HotkeyManager.MOD_CONTROL | HotkeyManager.MOD_SHIFT, Keys.Left, () => SendCmd("previous"));
            HotkeyManager.Register(form.Handle, HotkeyManager.MOD_CONTROL | HotkeyManager.MOD_SHIFT, Keys.Right, () => SendCmd("next"));
            HotkeyManager.Register(form.Handle, HotkeyManager.MOD_CONTROL | HotkeyManager.MOD_SHIFT, Keys.Space, () => SendCmd("toggle"));
            HotkeyManager.Register(form.Handle, HotkeyManager.MOD_CONTROL | HotkeyManager.MOD_SHIFT, Keys.OemOpenBrackets, () => { var _ = SwitchPlaylist(-1); });
            HotkeyManager.Register(form.Handle, HotkeyManager.MOD_CONTROL | HotkeyManager.MOD_SHIFT, Keys.OemCloseBrackets, () => { var _ = SwitchPlaylist(1); });
            HotkeyManager.Register(form.Handle, HotkeyManager.MOD_CONTROL | HotkeyManager.MOD_SHIFT, Keys.F, () => ToggleOverlay());

            pollTimer = new System.Windows.Forms.Timer();
            pollTimer.Interval = 2000;
            pollTimer.Tick += (s, e) => Poll();
            pollTimer.Start();

            TaskHelper.Run(() => Poll());
            TaskHelper.Run(async () => await LoadPlaylists());
        }

        public void ToggleOverlay()
        {
            overlayVisible = !overlayVisible;
            form.SetVisible(overlayVisible);
            if (overlayVisible) Poll();
        }

        private void Exit()
        {
            pollTimer.Stop();
            HotkeyManager.UnregisterAll(form.Handle);
            tray.Visible = false;
            Application.Exit();
        }

        public void SendCmd(string cmd)
        {
            TaskHelper.Run(() =>
            {
                try
                {
                    var req = (HttpWebRequest)WebRequest.Create(ApiBase + "/api/playback/" + cmd);
                    req.Method = "POST";
                    req.Timeout = 3000;
                                        using (var resp = (HttpWebResponse)req.GetResponse()) { }
                }
                catch { }
                Poll();
            });
        }

        private void Poll()
        {
            try
            {
                string title = "", artist = "", status = "none";
                var req = (HttpWebRequest)WebRequest.Create(ApiBase + "/api/queue");
                req.Method = "GET";
                req.Timeout = 3000;
                                string json;
                using (var resp = (HttpWebResponse)req.GetResponse())
                using (var sr = new StreamReader(resp.GetResponseStream(), Encoding.UTF8))
                    json = sr.ReadToEnd();

                var ser = new JavaScriptSerializer();
                var obj = (IDictionary<string, object>)ser.DeserializeObject(json);
                var items = obj.ContainsKey("items") ? obj["items"] as System.Collections.IList : null;
                int curIdx = obj.ContainsKey("currentIndex") ? Convert.ToInt32(obj["currentIndex"]) : 0;
                if (items != null && curIdx >= 0 && curIdx < items.Count)
                {
                    var item = (IDictionary<string, object>)items[curIdx];
                    var track = item["track"] as IDictionary<string, object>;
                    if (track != null)
                    {
                        title = Convert.ToString(track["title"]);
                        var artists = track.ContainsKey("artists") ? track["artists"] as System.Collections.IList : null;
                        if (artists != null && artists.Count > 0)
                        {
                            var a = artists[0] as IDictionary<string, object>;
                            artist = Convert.ToString(a["name"]);
                        }
                    }
                }

                var req2 = (HttpWebRequest)WebRequest.Create(ApiBase + "/api/playback");
                req2.Method = "GET";
                req2.Timeout = 3000;
                                string json2;
                using (var resp2 = (HttpWebResponse)req2.GetResponse())
                using (var sr2 = new StreamReader(resp2.GetResponseStream(), Encoding.UTF8))
                    json2 = sr2.ReadToEnd();
                var pb = (IDictionary<string, object>)ser.DeserializeObject(json2);
                status = Convert.ToString(pb["status"]);

                form.UpdateInfo(title, artist, status);
            }
            catch
            {
                form.UpdateInfo("Nuclear не запущен", "", "offline");
            }
        }

        private async System.Threading.Tasks.Task LoadPlaylists()
        {
            try
            {
                var raw = await McpCall("call", @"{ ""method"": ""Playlists.getIndex"", ""params"": {} }");
                DebugLog("getIndex raw: " + Truncate(raw, 500));
                string parsed = McpExtractText(raw);
                if (string.IsNullOrWhiteSpace(parsed) || parsed == "null")
                {
                    DebugLog("getIndex parsed empty/null");
                    return;
                }
                var ser = new JavaScriptSerializer();
                var list = ser.DeserializeObject(parsed) as System.Collections.IList;
                var result = new List<PlaylistInfo>();
                foreach (var o in list)
                {
                    var d = (IDictionary<string, object>)o;
                    result.Add(new PlaylistInfo
                    {
                        Id = Convert.ToString(d["id"]),
                        Name = Convert.ToString(d["name"])
                    });
                }
                playlists = result;
                form.SetPlaylists(result);
                DebugLog("Loaded playlists: " + result.Count);
            }
            catch (Exception ex)
            {
                DebugLog("LoadPlaylists EXC: " + ex);
            }
        }

        public async System.Threading.Tasks.Task PlayPlaylist(int index)
        {
            if (index < 0 || index >= playlists.Count) return;
            currentPlaylistIndex = index;
            var pl = playlists[index];
            try
            {
                var raw = await McpCall("call",
                    "{\"method\":\"Playlists.getPlaylist\",\"params\":{\"id\":\"" + pl.Id + "\"}}");
                string parsed = McpExtractText(raw);
                if (string.IsNullOrWhiteSpace(parsed) || parsed == "null") return;
                var ser = new JavaScriptSerializer();
                var root = (IDictionary<string, object>)ser.DeserializeObject(parsed);
                var items = root.ContainsKey("items") ? root["items"] as System.Collections.IList : null;
                if (items == null || items.Count == 0) return;

                var tracks = new ArrayList();
                foreach (var it in items)
                {
                    var item = (IDictionary<string, object>)it;
                    if (item.ContainsKey("track"))
                        tracks.Add(item["track"]);
                }
                if (tracks.Count == 0) return;

                var args = new Dictionary<string, object>
                {
                    { "method", "Queue.clearQueue" }, { "params", new Dictionary<string, object>() }
                };
                await McpCall("call", ser.Serialize(args));

                args = new Dictionary<string, object>
                {
                    { "method", "Queue.addToQueue" },
                    { "params", new Dictionary<string, object> { { "tracks", tracks } } }
                };
                await McpCall("call", ser.Serialize(args));

                args = new Dictionary<string, object>
                {
                    { "method", "Playback.play" }, { "params", new Dictionary<string, object>() }
                };
                await McpCall("call", ser.Serialize(args));

                form.ShowToast("Плейлист: " + pl.Name);
                Poll();
            }
            catch { }
        }

        public async System.Threading.Tasks.Task SwitchPlaylist(int delta)
        {
            if (playlists.Count == 0) { await LoadPlaylists(); if (playlists.Count == 0) return; }
            int next = currentPlaylistIndex < 0 ? 0 :
                (currentPlaylistIndex + delta + playlists.Count) % playlists.Count;
            await PlayPlaylist(next);
        }

        private static string McpExtractText(string sseText)
        {
            int last = sseText.LastIndexOf("data: {", StringComparison.Ordinal);
            if (last < 0) return sseText;
            int start = last + 6;
            int depth = 0, i = start;
            for (; i < sseText.Length; i++)
            {
                if (sseText[i] == '{') depth++;
                else if (sseText[i] == '}') { depth--; if (depth == 0) { i++; break; } }
            }
            var root = sseText.Substring(start, i - start);
            // unwrap MCP envelope: result.content[0].text
            try
            {
                var ser = new JavaScriptSerializer();
                var obj = (IDictionary<string, object>)ser.DeserializeObject(root);
                var result = obj["result"] as IDictionary<string, object>;
                if (result != null && result.ContainsKey("content"))
                {
                    var content = result["content"] as System.Collections.IList;
                    if (content != null && content.Count > 0)
                    {
                        var first = content[0] as IDictionary<string, object>;
                        if (first != null && first.ContainsKey("text"))
                            return Convert.ToString(first["text"]);
                    }
                }
            }
            catch { }
            return root;
        }

        public static async System.Threading.Tasks.Task<string> McpCall(string tool, string argsJson)
        {
            try
            {
                var initBody = "{\"jsonrpc\":\"2.0\",\"method\":\"initialize\",\"params\":{\"protocolVersion\":\"2024-11-05\",\"capabilities\":{},\"clientInfo\":{\"name\":\"nuclearisland\",\"version\":\"1.0\"}},\"id\":1}";
                string sid;
                var initResp = McpPost(McpBase, initBody, null, out sid);
                DebugLog("init: sid=" + (sid ?? "NULL") + " resp=" + Truncate(initResp, 200));
                if (sid == null) return "";
                var h2 = new Dictionary<string, string> { { "Mcp-Session-Id", sid } };
                string ignored;
                var iniRes = McpPost(McpBase, "{\"jsonrpc\":\"2.0\",\"method\":\"notifications/initialized\"}", h2, out ignored);
                DebugLog("initialized notice: " + Truncate(iniRes, 200));
                var callBody = "{\"jsonrpc\":\"2.0\",\"method\":\"tools/call\",\"params\":{\"name\":\"" + tool + "\",\"arguments\":" + argsJson + "},\"id\":2}";
                var res = McpPost(McpBase, callBody, h2, out ignored);
                DebugLog("call " + tool + " -> " + Truncate(res, 300));
                return res;
            }
            catch (Exception ex)
            {
                DebugLog("McpCall EXC for " + tool + ": " + ex);
                return "";
            }
        }

        private static string McpPost(string url, string body, Dictionary<string, string> headers, out string sessionId)
        {
            sessionId = null;
            try
            {
            var req = (HttpWebRequest)WebRequest.Create(url);
            req.Method = "POST";
            req.Timeout = 8000;
                        req.ContentType = "application/json";
            req.Accept = "application/json, text/event-stream";
            if (headers != null)
                foreach (var kv in headers) req.Headers[kv.Key] = kv.Value;
            var bytes = Encoding.UTF8.GetBytes(body);
            req.ContentLength = bytes.Length;
            using (var s = req.GetRequestStream()) s.Write(bytes, 0, bytes.Length);
            using (var resp = (HttpWebResponse)req.GetResponse())
            {
                if (resp.Headers["Mcp-Session-Id"] != null)
                    sessionId = resp.Headers["Mcp-Session-Id"];
                using (var sr = new StreamReader(resp.GetResponseStream(), Encoding.UTF8))
                    return sr.ReadToEnd();
            }
            }
            catch (Exception ex)
            {
                DebugLog("McpPost EXC: " + ex);
                return "";
            }
        }

        public static string Truncate(string s, int n)
        {
            if (string.IsNullOrEmpty(s)) return s;
            return s.Length <= n ? s : s.Substring(0, n);
        }

        public static void DebugLog(string msg)
        {
            try
            {
                var dir = Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location);
                var path = Path.Combine(dir, "nuclearisland.log");
                File.AppendAllText(path, "[" + DateTime.Now.ToString("HH:mm:ss") + "] " + msg + "\r\n");
            }
            catch { }
        }
    }

    public static class TaskHelper
    {
        public static void Run(Action a) { ThreadPool.QueueUserWorkItem(_ => a()); }
        public static void Run(Func<System.Threading.Tasks.Task> f)
        {
            ThreadPool.QueueUserWorkItem(async _ => { try { await f(); } catch { } });
        }
    }

    public class PlaylistInfo
    {
        public string Id;
        public string Name;
    }

    public class IslandForm : Form
    {
        private AppContext ctx;
        private Label titleLabel;
        private Label artistLabel;
        private Button prevBtn, playBtn, nextBtn;
        private ComboBox playlistBox;
        private Button playBtn2;
        private string lastInfoKey = "";

        public IslandForm(AppContext ctx)
        {
            this.ctx = ctx;
            FormBorderStyle = FormBorderStyle.None;
            TopMost = true;
            StartPosition = FormStartPosition.Manual;
            ShowInTaskbar = false;
            BackColor = Color.Black;
            Width = 740;
            Height = 64;
            var wa = Screen.PrimaryScreen.WorkingArea;
            Location = new Point(wa.Left + (wa.Width - Width) / 2, wa.Top + 8);

            var path = new GraphicsPath();
            path.AddArc(0, 0, 24, 24, 180, 90);
            path.AddArc(Width - 24, 0, 24, 24, 270, 90);
            path.AddArc(Width - 24, Height - 24, 24, 24, 0, 90);
            path.AddArc(0, Height - 24, 24, 24, 90, 90);
            path.CloseFigure();
            Region = new Region(path);

            titleLabel = new Label();
            titleLabel.ForeColor = Color.White;
            titleLabel.Font = new Font("Segoe UI", 10, FontStyle.Bold);
            titleLabel.AutoSize = true;
            titleLabel.Location = new Point(30, 8);
            titleLabel.BackColor = Color.Transparent;

            artistLabel = new Label();
            artistLabel.ForeColor = Color.FromArgb(200, 200, 200);
            artistLabel.Font = new Font("Segoe UI", 9);
            artistLabel.AutoSize = true;
            artistLabel.Location = new Point(31, 30);
            artistLabel.BackColor = Color.Transparent;

            prevBtn = MakeBtn("⏮", 150);
            playBtn = MakeBtn("▶", 185);
            nextBtn = MakeBtn("⏭", 220);
            prevBtn.Click += (s, e) => ctx.SendCmd("previous");
            nextBtn.Click += (s, e) => ctx.SendCmd("next");
            playBtn.Click += (s, e) => ctx.SendCmd("toggle");

            playlistBox = new ComboBox();
            playlistBox.DropDownStyle = ComboBoxStyle.DropDownList;
            playlistBox.Width = 300;
            playlistBox.Location = new Point(360, 16);
            playlistBox.BackColor = Color.FromArgb(30, 30, 30);
            playlistBox.ForeColor = Color.White;
            playlistBox.FlatStyle = FlatStyle.Flat;

            playBtn2 = new Button();
            playBtn2.Text = "Играть";
            playBtn2.FlatStyle = FlatStyle.Flat;
            playBtn2.BackColor = Color.FromArgb(50, 50, 50);
            playBtn2.ForeColor = Color.White;
            playBtn2.Size = new Size(70, 28);
            playBtn2.Location = new Point(660, 16);
            playBtn2.Click += (s, e) =>
            {
                if (playlistBox.SelectedIndex >= 0) { var _ = ctx.PlayPlaylist(playlistBox.SelectedIndex); }
            };

            Controls.Add(titleLabel);
            Controls.Add(artistLabel);
            Controls.Add(prevBtn);
            Controls.Add(playBtn);
            Controls.Add(nextBtn);
            Controls.Add(playlistBox);
            Controls.Add(playBtn2);
            Opacity = 0;
            Load += (s, e) => { AppContext.DebugLog("IslandForm Load: handle=" + Handle); FadeIn(); };
        }

        protected override void WndProc(ref Message m)
        {
            HotkeyManager.HandleMessage(this, m);
            base.WndProc(ref m);
        }

        public void SetVisible(bool visible)
        {
            if (visible) { Show(); FadeIn(); }
            else FadeOut();
        }

        private System.Windows.Forms.Timer fadeTimer;
        private int target = 95;
        private void FadeIn()
        {
            target = 95;
            StartFade();
        }
        private void FadeOut()
        {
            target = 0;
            StartFade();
        }
        private void StartFade()
        {
            if (fadeTimer == null)
            {
                fadeTimer = new System.Windows.Forms.Timer();
                fadeTimer.Interval = 10;
                fadeTimer.Tick += (s, e) =>
                {
                    if (target > 50) { Opacity += 0.06; if (Opacity >= 0.95) { Opacity = 0.95; fadeTimer.Stop(); } }
                    else { Opacity -= 0.06; if (Opacity <= 0.01) { Opacity = 0; Hide(); fadeTimer.Stop(); } }
                };
            }
            fadeTimer.Start();
        }

        private Button MakeBtn(string text, int x)
        {
            var b = new Button();
            b.Text = text;
            b.FlatStyle = FlatStyle.Flat;
            b.FlatAppearance.BorderSize = 0;
            b.BackColor = Color.FromArgb(45, 45, 48);
            b.ForeColor = Color.White;
            b.Font = new Font("Segoe UI", 11);
            b.Size = new Size(34, 28);
            b.Location = new Point(x, 16);
            b.MouseEnter += (s, e) => b.BackColor = Color.FromArgb(70, 70, 75);
            b.MouseLeave += (s, e) => b.BackColor = Color.FromArgb(45, 45, 48);
            return b;
        }

        public void UpdateInfo(string title, string artist, string status)
        {
            string key = title + "|" + artist + "|" + status;
            if (key != lastInfoKey)
            {
                AppContext.DebugLog("UpdateInfo: " + key);
                lastInfoKey = key;
            }
            if (InvokeRequired) { BeginInvoke((Action)(() => UpdateInfo(title, artist, status))); return; }
            titleLabel.Text = string.IsNullOrEmpty(title) ? "—" : title;
            artistLabel.Text = string.IsNullOrEmpty(artist) ? "" : artist;
            if (status == "playing") playBtn.Text = "⏸";
            else if (status == "offline") playBtn.Text = "✖";
            else playBtn.Text = "▶";
        }

        public void SetPlaylists(List<PlaylistInfo> pl)
        {
            if (InvokeRequired) { BeginInvoke((Action)(() => SetPlaylists(pl))); return; }
            playlistBox.Items.Clear();
            foreach (var p in pl) playlistBox.Items.Add(p.Name);
        }

        public void ShowToast(string msg)
        {
            if (InvokeRequired) { BeginInvoke((Action)(() => ShowToast(msg))); return; }
            ToastForm.Show(msg);
        }
    }

    public static class ToastForm
    {
        private static Form f;
        public static void Show(string msg)
        {
            if (f != null) { try { f.Close(); } catch { } }
            f = new Form();
            f.FormBorderStyle = FormBorderStyle.None;
            f.TopMost = true;
            f.ShowInTaskbar = false;
            f.BackColor = Color.Black;
            f.Opacity = 0.92;
            var lbl = new Label();
            lbl.Text = msg;
            lbl.ForeColor = Color.White;
            lbl.Font = new Font("Segoe UI", 10, FontStyle.Bold);
            lbl.AutoSize = true;
            lbl.Padding = new Padding(14);
            f.Controls.Add(lbl);
            var pref = lbl.PreferredSize;
            f.ClientSize = new Size(pref.Width + 28, pref.Height + 24);
            lbl.Location = new Point(14, 12);
            var wa = Screen.PrimaryScreen.WorkingArea;
            f.Location = new Point(wa.Left + (wa.Width - f.Width) / 2, wa.Top + 80);
            f.Show();
            var t = new System.Windows.Forms.Timer();
            t.Interval = 2000;
            t.Tick += (s, e) => { t.Stop(); try { f.Close(); } catch { } };
            t.Start();
        }
    }

    public static class HotkeyManager
    {
        public const uint MOD_CONTROL = 0x0002;
        public const uint MOD_SHIFT = 0x0004;
        private const int WM_HOTKEY = 0x0312;
        private static Dictionary<int, Action> actions = new Dictionary<int, Action>();
        private static int nextId = 1;

        public static void Register(IntPtr hwnd, uint mods, Keys key, Action action)
        {
            int id = nextId++;
            if (RegisterHotKey(hwnd, id, mods, (uint)key)) actions[id] = action;
            else actions[id] = action;
        }

        public static void UnregisterAll(IntPtr hwnd)
        {
            foreach (var id in actions.Keys) UnregisterHotKey(hwnd, id);
            actions.Clear();
        }

        public static void HandleMessage(Control target, Message m)
        {
            if (m.Msg == WM_HOTKEY)
            {
                int id = m.WParam.ToInt32();
                if (actions.ContainsKey(id)) actions[id]();
            }
        }

        [DllImport("user32.dll", SetLastError = true)]
        private static extern bool RegisterHotKey(IntPtr hWnd, int id, uint fsModifiers, uint vk);
        [DllImport("user32.dll", SetLastError = true)]
        private static extern bool UnregisterHotKey(IntPtr hWnd, int id);
    }

    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            WebRequest.DefaultWebProxy = null;
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new AppContext());
        }
    }
}